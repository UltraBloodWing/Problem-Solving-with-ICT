using System;

namespace TransportRegistry{

    public enum TransportType{

        Car,
        Motorbike,
        Truck
    }
}