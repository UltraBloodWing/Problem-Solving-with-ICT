using System;

namespace PassTask13{
    public enum Type{
        Foods,
        Electronics,
        Toys,
        Entertainment,
        Fashion,
        Leisure,
        Others
    }
}